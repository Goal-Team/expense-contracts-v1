@php
    $matchBadges = [
        'exact'      => '<span class="badge bg-success">PAN + Name</span>',
        'pan_only'   => '<span class="badge bg-primary">PAN Only</span>',
        'name_only'  => '<span class="badge bg-warning">Name Only</span>',
        'fuzzy_name' => '<span class="badge bg-info">Fuzzy Name</span>',
    ];

    // Client-side pagination settings
    $perPage = 100;
    $matchedTotal = count($matched);
    $unmatchedTotal = count($unmatched);
    $matchedPages = max(1, ceil($matchedTotal / $perPage));
    $unmatchedPages = max(1, ceil($unmatchedTotal / $perPage));
@endphp

<div class="card">
    <div class="card-header">
        <h5 class="card-title">
            Vendor Import Results
            <small class="text-muted">({{ number_format($matchedTotal + $unmatchedTotal) }} total rows)</small>
        </h5>
        <ul class="nav nav-tabs card-header-tabs" id="vendorImportTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="matched-tab" data-bs-toggle="tab"
                    data-bs-target="#matched-panel" type="button" role="tab" aria-controls="matched-panel"
                    aria-selected="true">
                    Matched <span class="badge bg-label-success ms-1">{{ number_format($matchedTotal) }}</span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="unmatched-tab" data-bs-toggle="tab"
                    data-bs-target="#unmatched-panel" type="button" role="tab" aria-controls="unmatched-panel"
                    aria-selected="false">
                    Unmatched <span class="badge bg-label-danger ms-1">{{ number_format($unmatchedTotal) }}</span>
                </button>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content">

            {{-- Tab 1: Matched Vendors --}}
            <div class="tab-pane fade show active" id="matched-panel" role="tabpanel" aria-labelledby="matched-tab">
                @if ($matchedTotal > 0)
                <div class="mb-3 d-flex align-items-center gap-2 flex-wrap">
                    <button type="button" class="btn btn-success" id="validateSelectedBtn" disabled>
                        <i class="ti ti-check me-1"></i> Validate Selected (<span id="selectedCount">0</span>)
                    </button>
                    <button type="button" class="btn btn-outline-success" id="validateAllPageBtn">
                        <i class="ti ti-checks me-1"></i> Validate All on Page
                    </button>
                    <span class="text-muted ms-2" id="matchedPageInfo"></span>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-sm" id="matchedTable">
                        <thead>
                            <tr>
                                <th style="width:30px;"><input type="checkbox" id="selectAllMatched" class="form-check-input"></th>
                                <th>S.No</th>
                                <th>Vendor Code</th>
                                <th>Active V.Code</th>
                                <th>Vendor Name (Excel)</th>
                                <th>PAN (Excel)</th>
                                <th>Party Name (System)</th>
                                <th>PAN (System)</th>
                                <th>Match Type</th>
                                <th>Contracts</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="matchedBody"></tbody>
                    </table>
                </div>
                {{-- Matched Pagination --}}
                <nav id="matchedPagination" class="mt-3">
                    <ul class="pagination pagination-sm flex-wrap" id="matchedPageLinks"></ul>
                </nav>
                @else
                <div class="alert alert-warning">No matched vendors found.</div>
                @endif
            </div>

            {{-- Tab 2: Unmatched Vendors --}}
            <div class="tab-pane fade" id="unmatched-panel" role="tabpanel" aria-labelledby="unmatched-tab">
                @if ($unmatchedTotal > 0)
                <div class="mb-3">
                    <form action="{{ route('parties.vendor_import_export') }}" method="POST" style="display:inline;">
                        @csrf
                        <input type="hidden" name="batch_id" value="{{ $batchId }}">
                        <button type="submit" class="btn btn-warning">
                            <i class="ti ti-download me-1"></i> Export Unmatched as Excel
                        </button>
                    </form>
                    <span class="text-muted ms-2" id="unmatchedPageInfo"></span>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-sm" id="unmatchedTable">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Vendor Code</th>
                                <th>Active Vendor Code</th>
                                <th>Vendor Name</th>
                                <th>PAN</th>
                            </tr>
                        </thead>
                        <tbody id="unmatchedBody"></tbody>
                    </table>
                </div>
                {{-- Unmatched Pagination --}}
                <nav id="unmatchedPagination" class="mt-3">
                    <ul class="pagination pagination-sm flex-wrap" id="unmatchedPageLinks"></ul>
                </nav>
                @else
                <div class="alert alert-info">All vendors were matched successfully!</div>
                @endif
            </div>

        </div>

        <div class="mt-3">
            <a href="{{ route('parties.vendor_import_view') }}" class="btn btn-label-secondary">
                <i class="ti ti-arrow-left me-1"></i> Upload Another File
            </a>
            <a href="{{ route('parties.parties') }}" class="btn btn-label-secondary ms-2">Back to Parties</a>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const validateUrl = "{{ route('parties.vendor_import_validate') }}";
    const csrfToken = "{{ csrf_token() }}";
    const PER_PAGE = {{ $perPage }};

    // Data passed from server (embedded as JSON)
    const matchedData = @json($matched);
    const unmatchedData = @json($unmatched);

    const matchBadges = {
        'exact':      '<span class="badge bg-success">PAN + Name</span>',
        'pan_only':   '<span class="badge bg-primary">PAN Only</span>',
        'name_only':  '<span class="badge bg-warning">Name Only</span>',
        'fuzzy_name': '<span class="badge bg-info">Fuzzy Name</span>',
    };

    let matchedPage = 1;
    let unmatchedPage = 1;

    // ---- Matched Table Rendering with Pagination ----
    function renderMatchedPage(page) {
        matchedPage = page;
        const start = (page - 1) * PER_PAGE;
        const end = Math.min(start + PER_PAGE, matchedData.length);
        const slice = matchedData.slice(start, end);

        let html = '';
        slice.forEach(function (item, i) {
            const globalIdx = start + i;
            const r = item.excel_row;
            const alreadyValid = item.already_valid == 1;
            html += '<tr data-idx="' + globalIdx + '" data-party-id="' + item.party_id + '"'
                + ' data-vendor-code="' + escHtml(r.vendor_code) + '"'
                + ' data-active-vendor-code="' + escHtml(r.active_vendor_code) + '">';
            html += '<td>';
            if (alreadyValid) {
                html += '<span class="badge bg-label-secondary">Done</span>';
            } else {
                html += '<input type="checkbox" class="form-check-input row-check" value="' + globalIdx + '">';
            }
            html += '</td>';
            html += '<td>' + (r.s_no || (globalIdx + 1)) + '</td>';
            html += '<td>' + escHtml(r.vendor_code) + '</td>';
            html += '<td>' + escHtml(r.active_vendor_code) + '</td>';
            html += '<td>' + escHtml(r.vendor_name) + '</td>';
            html += '<td>' + escHtml(r.pan) + '</td>';
            html += '<td>' + escHtml(item.party_name) + '</td>';
            html += '<td>' + escHtml(item.party_pan) + '</td>';
            html += '<td>' + (matchBadges[item.match_type] || item.match_type) + '</td>';
            html += '<td>';
            if (item.contracts > 0) {
                html += '<span class="badge bg-label-primary">' + item.contracts + '</span>';
            } else {
                html += '<span class="text-muted">None</span>';
            }
            html += '</td>';
            html += '<td>';
            if (alreadyValid) {
                html += '<button class="btn btn-sm btn-label-secondary" disabled><i class="ti ti-check"></i> Already Valid</button>';
            } else {
                html += '<button class="btn btn-sm btn-success validate-single-btn"'
                    + ' data-party-id="' + item.party_id + '"'
                    + ' data-vendor-code="' + escHtml(r.vendor_code) + '"'
                    + ' data-active-vendor-code="' + escHtml(r.active_vendor_code) + '">'
                    + '<i class="ti ti-check"></i> Valid</button>';
            }
            html += '</td></tr>';
        });
        qs('#matchedBody').innerHTML = html;
        const selectAllMatched = qs('#selectAllMatched');
        if (selectAllMatched) {
            selectAllMatched.checked = false;
        }
        updateSelectedCount();
        renderPagination('#matchedPageLinks', matchedData.length, page, function (p) { renderMatchedPage(p); });
        const info = qs('#matchedPageInfo');
        if (info) {
            info.textContent = 'Showing ' + (start + 1).toLocaleString() + '-' + end.toLocaleString() + ' of ' + matchedData.length.toLocaleString();
        }
    }

    // ---- Unmatched Table Rendering with Pagination ----
    function renderUnmatchedPage(page) {
        unmatchedPage = page;
        const start = (page - 1) * PER_PAGE;
        const end = Math.min(start + PER_PAGE, unmatchedData.length);
        const slice = unmatchedData.slice(start, end);

        let html = '';
        slice.forEach(function (item, i) {
            const r = item.excel_row;
            html += '<tr>';
            html += '<td>' + (r.s_no || (start + i + 1)) + '</td>';
            html += '<td>' + escHtml(r.vendor_code) + '</td>';
            html += '<td>' + escHtml(r.active_vendor_code) + '</td>';
            html += '<td>' + escHtml(r.vendor_name) + '</td>';
            html += '<td>' + escHtml(r.pan) + '</td>';
            html += '</tr>';
        });
        qs('#unmatchedBody').innerHTML = html;
        renderPagination('#unmatchedPageLinks', unmatchedData.length, page, function (p) { renderUnmatchedPage(p); });
        const info = qs('#unmatchedPageInfo');
        if (info) {
            info.textContent = 'Showing ' + (start + 1).toLocaleString() + '-' + end.toLocaleString() + ' of ' + unmatchedData.length.toLocaleString();
        }
    }

    // ---- Pagination Renderer ----
    function renderPagination(selector, totalItems, currentPage, callback) {
        const totalPages = Math.ceil(totalItems / PER_PAGE);
        const container = qs(selector);
        if (!container) return;
        if (totalPages <= 1) {
            container.innerHTML = '';
            return;
        }

        let html = '';
        html += '<li class="page-item ' + (currentPage === 1 ? 'disabled' : '') + '"><a class="page-link" href="#" data-page="' + (currentPage - 1) + '">&laquo;</a></li>';

        // Show max 10 page links around current page
        let startP = Math.max(1, currentPage - 5);
        let endP = Math.min(totalPages, startP + 9);
        if (endP - startP < 9) startP = Math.max(1, endP - 9);

        if (startP > 1) html += '<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li><li class="page-item disabled"><span class="page-link">...</span></li>';

        for (let p = startP; p <= endP; p++) {
            html += '<li class="page-item ' + (p === currentPage ? 'active' : '') + '"><a class="page-link" href="#" data-page="' + p + '">' + p + '</a></li>';
        }

        if (endP < totalPages) html += '<li class="page-item disabled"><span class="page-link">...</span></li><li class="page-item"><a class="page-link" href="#" data-page="' + totalPages + '">' + totalPages + '</a></li>';

        html += '<li class="page-item ' + (currentPage === totalPages ? 'disabled' : '') + '"><a class="page-link" href="#" data-page="' + (currentPage + 1) + '">&raquo;</a></li>';

        container.innerHTML = html;
        container.onclick = function (e) {
            const link = e.target.closest('a.page-link');
            if (!link) return;
            e.preventDefault();
            const p = parseInt(link.dataset.page, 10);
            if (p >= 1 && p <= totalPages) callback(p);
        };
    }

    function escHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function updateSelectedCount() {
        const cnt = qsa('.row-check:checked').length;
        const selectedCount = qs('#selectedCount');
        if (selectedCount) {
            selectedCount.textContent = String(cnt);
        }
        const validateSelectedBtn = qs('#validateSelectedBtn');
        if (validateSelectedBtn) {
            validateSelectedBtn.disabled = cnt === 0;
        }
    }

    // ---- Events ----
    const selectAllMatched = qs('#selectAllMatched');
    if (selectAllMatched) {
        selectAllMatched.addEventListener('change', function () {
            qsa('.row-check').forEach(function (el) {
                el.checked = selectAllMatched.checked;
            });
            updateSelectedCount();
        });
    }

    document.addEventListener('change', function (e) {
        if (!e.target.classList.contains('row-check')) return;
        updateSelectedCount();
        if (!e.target.checked && selectAllMatched) selectAllMatched.checked = false;
        const allChecks = qsa('.row-check');
        const checked = qsa('.row-check:checked');
        if (selectAllMatched && checked.length === allChecks.length && allChecks.length > 0) {
            selectAllMatched.checked = true;
        }
    });

    // Single validate
    document.addEventListener('click', function (e) {
        const btn = e.target.closest('.validate-single-btn');
        if (!btn) return;
        const items = [{
            party_id: btn.dataset.partyId,
            vendor_code: btn.dataset.vendorCode,
            active_vendor_code: btn.dataset.activeVendorCode
        }];
        sendValidation(items, function () {
            btn.disabled = true;
            btn.innerHTML = '<i class="ti ti-check"></i> Valid ✓';
            const tr = btn.closest('tr');
            const rowCheck = tr ? tr.querySelector('.row-check') : null;
            if (rowCheck) {
                rowCheck.disabled = true;
                rowCheck.checked = false;
            }
            // Update data
            const idx = tr ? Number(tr.dataset.idx) : -1;
            if (matchedData[idx]) matchedData[idx].already_valid = 1;
            updateSelectedCount();
        });
    });

    // Bulk validate selected
    const validateSelectedBtn = qs('#validateSelectedBtn');
    if (validateSelectedBtn) {
        validateSelectedBtn.addEventListener('click', function () {
        const items = [];
        const rows = [];
        qsa('.row-check:checked').forEach(function (checkbox) {
            const row = checkbox.closest('tr');
            items.push({
                party_id: row.dataset.partyId,
                vendor_code: row.dataset.vendorCode,
                active_vendor_code: row.dataset.activeVendorCode
            });
            rows.push(row);
        });
        if (items.length === 0) return;

        sendValidation(items, function () {
            rows.forEach(function (row) {
                const idx = Number(row.dataset.idx);
                const singleBtn = row.querySelector('.validate-single-btn');
                const rowCheck = row.querySelector('.row-check');
                if (singleBtn) {
                    singleBtn.disabled = true;
                    singleBtn.innerHTML = '<i class="ti ti-check"></i> Valid ✓';
                }
                if (rowCheck) {
                    rowCheck.disabled = true;
                    rowCheck.checked = false;
                }
                if (matchedData[idx]) matchedData[idx].already_valid = 1;
            });
            if (selectAllMatched) selectAllMatched.checked = false;
            updateSelectedCount();
        });
    });
    }

    // Validate all on current page
    const validateAllPageBtn = qs('#validateAllPageBtn');
    if (validateAllPageBtn) {
        validateAllPageBtn.addEventListener('click', function () {
        const items = [];
        const rows = [];
        qsa('#matchedBody tr').forEach(function (row) {
            const chk = row.querySelector('.row-check');
            if (chk && !chk.disabled) {
                items.push({
                    party_id: row.dataset.partyId,
                    vendor_code: row.dataset.vendorCode,
                    active_vendor_code: row.dataset.activeVendorCode
                });
                rows.push(row);
            }
        });
        if (items.length === 0) { alert('No rows to validate on this page.'); return; }

        sendValidation(items, function () {
            rows.forEach(function (row) {
                const idx = Number(row.dataset.idx);
                const singleBtn = row.querySelector('.validate-single-btn');
                const rowCheck = row.querySelector('.row-check');
                if (singleBtn) {
                    singleBtn.disabled = true;
                    singleBtn.innerHTML = '<i class="ti ti-check"></i> Valid ✓';
                }
                if (rowCheck) {
                    rowCheck.disabled = true;
                    rowCheck.checked = false;
                }
                if (matchedData[idx]) matchedData[idx].already_valid = 1;
            });
            if (selectAllMatched) selectAllMatched.checked = false;
            updateSelectedCount();
        });
    });
    }

    async function sendValidation(items, onSuccess) {
        // Chunk validation requests for large batches
        const VALIDATE_CHUNK = 200;
        if (items.length > VALIDATE_CHUNK) {
            let totalSuccess = 0;
            async function sendBatch(start) {
                const batch = items.slice(start, start + VALIDATE_CHUNK);
                if (batch.length === 0) {
                    if (typeof window.toastr !== 'undefined') {
                        window.toastr.success(totalSuccess + ' vendor(s) validated successfully.');
                    } else {
                        alert(totalSuccess + ' vendor(s) validated successfully.');
                    }
                    onSuccess();
                    return;
                }
                try {
                    const resp = await requestJson(validateUrl, {
                        items: batch,
                    });
                    if (resp.status) {
                        totalSuccess += batch.length;
                        await sendBatch(start + VALIDATE_CHUNK);
                    } else {
                        alert(resp.message || 'Validation failed.');
                    }
                } catch (error) {
                    alert('Error: ' + error.message);
                }
            }
            await sendBatch(0);
            return;
        }

        try {
            const resp = await requestJson(validateUrl, {
                items: items,
            });
            if (resp.status) {
                if (typeof window.toastr !== 'undefined') {
                    window.toastr.success(resp.message);
                } else {
                    alert(resp.message);
                }
                onSuccess();
            } else {
                alert(resp.message || 'Validation failed.');
            }
        } catch (error) {
            alert('Error: ' + error.message);
        }
    }

    async function requestJson(url, payload) {
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': csrfToken,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        });
        const data = await res.json().catch(function () { return {}; });
        if (!res.ok) {
            throw new Error(data.message || 'Something went wrong.');
        }
        return data;
    }

    function qs(selector) {
        return document.querySelector(selector);
    }

    function qsa(selector) {
        return Array.from(document.querySelectorAll(selector));
    }

    // Initial render
    if (matchedData.length > 0) renderMatchedPage(1);
    if (unmatchedData.length > 0) renderUnmatchedPage(1);
});
</script>
