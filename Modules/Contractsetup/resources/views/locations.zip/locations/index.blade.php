@extends('layouts/layoutMaster')

@section('title', 'Location Master')

@section('page-script')
<link href="{{url('/')}}/assets/css/custom.css" rel="stylesheet" />
@endsection

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h4>Locations</h4>
        <a href="{{ route('contract-setup.locations.create') }}" class="btn btn-primary">Add Location</a>
    </div>
    <div class="card-body">
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Code</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($locations as $loc)
                <tr>
                    <td>{{ $loc->id }}</td>
                    <td>{{ $loc->location_name }}</td>
                    <td>{{ $loc->location_code }}</td>
                    <td>{{ $loc->city }}</td>
                    <td>{{ $loc->state }}</td>
                    <td>{{ $loc->status ? 'Active' : 'Inactive' }}</td>
                    <td>
                        <a class="btn btn-sm btn-info" href="{{ route('contract-setup.locations.edit', $loc->id) }}">Edit</a>
                        <form action="{{ route('contract-setup.locations.destroy', $loc->id) }}" method="POST" style="display:inline-block;" onsubmit="return confirm('Delete this location?');">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        {{ $locations->links() }}
    </div>
</div>
@endsection