@extends('layouts/layoutMaster')

@section('title', 'Create Location')

@section('content')
<div class="card">
    <div class="card-header"><h4>Create Location</h4></div>
    <div class="card-body">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form method="POST" action="{{ route('contract-setup.locations.store') }}">
            @csrf
            <div class="mb-3">
                <label class="form-label">Location Name</label>
                <input type="text" name="location_name" class="form-control" value="{{ old('location_name') }}" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Location Code</label>
                <input type="text" name="location_code" class="form-control" value="{{ old('location_code') }}">
            </div>
            <div class="mb-3">
                <label class="form-label">City</label>
                <input type="text" name="city" class="form-control" value="{{ old('city') }}">
            </div>
            <div class="mb-3">
                <label class="form-label">State</label>
                <input type="text" name="state" class="form-control" value="{{ old('state') }}">
            </div>
            <div class="mb-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="1">Active</option>
                    <option value="0">Inactive</option>
                </select>
            </div>
            <button class="btn btn-primary">Create</button>
            <a href="{{ route('contract-setup.locations.index') }}" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>
@endsection