@extends('layouts/layoutMaster')

@section('title', 'Edit Location')

@section('content')
<div class="card">
    <div class="card-header"><h4>Edit Location</h4></div>
    <div class="card-body">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form method="POST" action="{{ route('contract-setup.locations.update', $location->id) }}">
            @csrf
            @method('PUT')
            <div class="mb-3">
                <label class="form-label">Location Name</label>
                <input type="text" name="location_name" class="form-control" value="{{ old('location_name', $location->location_name) }}" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Location Code</label>
                <input type="text" name="location_code" class="form-control" value="{{ old('location_code', $location->location_code) }}">
            </div>
            <div class="mb-3">
                <label class="form-label">City</label>
                <input type="text" name="city" class="form-control" value="{{ old('city', $location->city) }}">
            </div>
            <div class="mb-3">
                <label class="form-label">State</label>
                <input type="text" name="state" class="form-control" value="{{ old('state', $location->state) }}">
            </div>
            <div class="mb-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="1" {{ $location->status ? 'selected' : '' }}>Active</option>
                    <option value="0" {{ !$location->status ? 'selected' : '' }}>Inactive</option>
                </select>
            </div>
            <button class="btn btn-primary">Save</button>
            <a href="{{ route('contract-setup.locations.index') }}" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>
@endsection