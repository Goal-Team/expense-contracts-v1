@extends('contract-setup::layouts.admin')

@section('content')
<!-- <a href="/contract/create" class="btn">Create contract</a>
<table width="100%" style="width: 100%">
    <thead>
        <tr>
            <th>Id</th>
            <th>Contract mode</th>
            <th>Contract name</th>
            <th>Contract description</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($contracts as $contract)
        <tr>
            <td data-label="Id">{{ $contract->id }}</td>
            <td data-label="Contract mode"> {{ $contract->contract_mode }}</td>
            <td data-label="Contract name"> {{ $contract->contract_name }}</td>
            <td data-label="Contract description"> {{ $contract->contract_description }}</td>
        </tr>
        @endforeach
    </tbody>
</table> -->
<style>
    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }

    @media (max-width: 600px) {
        table {
            display: block;
        }

        thead {
            opacity: 0;
        }

        thead tr {
            padding: 0;
            height: 0;
        }

        tr {
            border-bottom: 1px solid #dddddd;
            display: block;
            margin-bottom: 10px;
        }

        td {
            border: none;
            display: block;
            text-align: right;
        }

        td:before {
            content: attr(data-label);
            float: left;
            font-weight: bold;
        }
    }
</style>


<table id="example" class="display nowrap" style="width:100%">
    <thead>
        <tr>

            <th>ID</th>
            <th>Contract Mode
                <input type="text" placeholder="Search" class="form-control form-control-sm" />
            </th>
            <th>Contract Name
                <input type="text" placeholder="Search" class="form-control form-control-sm" />
            </th>
            <th>contract Type
                <input type="text" placeholder="Search" class="form-control form-control-sm" />
            </th>
            <th>Contract Description
                <input type="text" placeholder="Search" class="form-control form-control-sm" />
            </th>
            <th>Signing Date
                <input type="text" placeholder="Search" class="form-control form-control-sm" />
            </th>
            <th>Commencement Type
                <input type="text" placeholder="Search" class="form-control form-control-sm" />
            </th>
            <th>Fixed Date
                <input type="text" placeholder="Search" class="form-control form-control-sm" />
            </th>
            <th>End Contract Type
                <input type="text" placeholder="Search" class="form-control form-control-sm" />
            </th>
            <th>Onetime End Date
                <input type="text" placeholder="Search" class="form-control form-control-sm" />
            </th>
        </tr>
    </thead>
</table>
<script>
    $('#example thead input').on('keyup change', function() {
        var index = $(this).closest('th').index();
        $('#example').DataTable().column(index).search(this.value).draw();
    });

    new DataTable('#example', {
        ajax: 'contracts/data',
        processing: true,
        serverSide: false,
        "scrollX": true,
        "columnDefs": [{
                "targets": [0], 
                "searchable": true,
                "orderable": true
            },
            {
                "targets": 2,
                "render": function(data, type, row, meta) { 
                    if (type === 'display') { 
                        return '<a href="/contract/'+row[0]+'" class="custom-tag">' + data + '</a>';
                    } else {
                        return data; // Return the original data for filtering
                    }
                }
            }
            // Add additional column definitions as needed
        ],
        // "createdRow": function(row, data, dataIndex) {
        //     // Set data-label attribute for each td
        //     $(row).addClass('custom-row-class');

        //     // Manipulate each <td> element
        //     $(row).find('td').each(function(index, td) {
        //         // Add custom HTML to each <td> element
        //         // For example, add a <span> element
        //         $(td).html('<span>' + $(td).html() + '</span>');
        //     });

        // }
    });
</script>
@endsection
@section('footer')
@endsection