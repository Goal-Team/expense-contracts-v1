  
<div class="row" style="" id="">
      <div class="col-md-6 user_row_ repeater">
        <div class="row" style="" id="">
          <div class="col-md-6 select_users" style="margin-top: 20px;">
            <select class="form-select users approval_user" aria-label="select example" data-id="{{$index}}" id="approval_required_users_{{$index}}" name="approval_required_users[]">
              <option value="">Select Approver</option>
              @foreach($add_users as $add_users_data)
                  <option id="{{$add_users_data->id}}" value="{{$add_users_data->id}}:{{$add_users_data->FirstName}}">{{$add_users_data->FirstName}}</option>
              @endforeach
            </select>
          </div>
          <div class="col-md-6 user_row_operation select_users_btn" style="margin-top: 20px;text-align: center;">
            <a id="" class="btn-danger btn-delete" style="font-size: 12px;color: #fff !important;cursor: pointer;"><i class="ti ti-minus me-1"></i> </a>
          </div>
        </div>
      </div>

</div>