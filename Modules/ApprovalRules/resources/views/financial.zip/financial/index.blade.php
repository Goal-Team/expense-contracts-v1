@extends('layouts/layoutMaster')

@section('title', 'DataTables - Advanced Tables')

<!-- Vendor Styles -->
@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
  'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
  'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
  'resources/assets/vendor/libs/moment/moment.js',
  'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

<!-- Page Scripts -->
@section('page-script')
@vite([
'resources/assets/js/tables-datatables-advanced.js'
])
<script type="module" src="{{url('/')}}/Modules/ApprovalRules/resources/assets/js/approvalrule.js"></script>
@endsection
 @section('content')
    <link href="https://cdn.datatables.net/v/dt/dt-2.0.8/datatables.min.css" rel="stylesheet">

 
   <style type="text/css">
      /* body {
          margin-top: 20px;
          background-color: #eee;
        }
        table {
          border: 0;
          border-collapse: collapse;
          margin: 0;
          padding: 0;
          width: 100%;
          table-layout: fixed;
        }
        table caption {
          text-align: left;
          font-size: 1.3em;
          margin: 0.5em 0 0.75em;
        }
        table tr {
          display: block;
          border: 1px solid #eee;
          padding: 1em 1em 0.5em;
        }
        table tr + tr {
          margin-top: 0.625em;
        }*/
        table thead {
          display: none;
        }
        table td {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          border-bottom: 1px solid #eee;
          font-size: 15px;
          line-height: 1.35em;
        }
        table td:before {
          content: attr(data-label);
          font-size: 0.9em;
          text-align: left;
          font-weight: bold;
          text-transform: uppercase;
          max-width: 45%;
          color: #545454;
        }
        table td + td {
          margin-top: 0.8em;
        }
        table td:last-child {
          border-bottom: 0;
        }
        .project-list-table {
          border-collapse: separate;
          border-spacing: 0 12px
        }

        .project-list-table tr {
          background-color: #fff
        }

        .table-nowrap td,
        .table-nowrap th {
          white-space: nowrap;
        }

        .table-borderless>:not(caption)>*>* {
          border-bottom-width: 0;
        }

        .table>:not(caption)>*>* {
          padding: 0.75rem 0.75rem;
          background-color: var(--bs-table-bg);
          border-bottom-width: 1px;
          box-shadow: inset 0 0 0 9999px var(--bs-table-accent-bg);
        }

        .avatar-sm {
          height: 2rem;
          width: 2rem;
        }

        .rounded-circle {
          border-radius: 50% !important;
        }

        .me-2 {
          margin-right: 0.5rem !important;
        }

        img,
        svg {
          vertical-align: middle;
        }

        a {
          color: #3b76e1;
          text-decoration: none;
        }

        .badge-soft-danger {
          color: #f56e6e !important;
          background-color: rgba(245, 110, 110, .1);
        }

        .badge-soft-success {
          color: #63ad6f !important;
          background-color: rgba(99, 173, 111, .1);
        }

        .badge-soft-primary {
          color: #3b76e1 !important;
          background-color: rgba(59, 118, 225, .1);
        }

        .badge-soft-info {
          color: #57c9eb !important;
          background-color: rgba(87, 201, 235, .1);
        }

        .avatar-title {
          align-items: center;
          background-color: #3b76e1;
          color: #fff;
          display: flex;
          font-weight: 500;
          height: 100%;
          justify-content: center;
          width: 100%;
        }

        .bg-soft-primary {
          background-color: rgba(59, 118, 225, .25) !important;
        }
        #financial_list_table_length,#financial_list_table_filter
        {
          display: none;
        }
        @media screen and (min-width: 600px) {
          table caption {
            font-size: 1.5em;
          }
          table thead {
            display: table-header-group;
          }
          /*table tr {
            display: table-row;
            border: 0;
          }*/
          table th, table td {
            text-align: center;
          }
          table th {
            font-size: 0.85em;
            text-transform: uppercase;
          }
          table td {
            display: table-cell;
          }
          table td:before {
            display: none;
          }
          table td:last-child {
            border-bottom: 1px solid #eee;
          }
        }
    </style>
      <div class="container">
        <div class="row  align-items-center">
          @if ($message = Session::get('success'))
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <b>{{ $message }}</b>
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
          @endif
          <div class="col-md-6">
            <div class="mb-3">
              <h5 class="card-title">Financial List <span class="text-muted fw-normal ms-2"></span>
              </h5>
            </div>
          </div>
          <div class="col-md-6">
            <div class="d-flex flex-wrap align-items-center justify-content-end gap-2 mb-3">
              <div>
                <a href="{{url('/')}}/contract-setup/financial-add" class="btn btn-primary">
                  <i class="bx bx-plus me-1"></i> Add New </a>
              </div>
              <!-- <div class="dropdown">
                <a class="btn btn-link text-muted py-1 font-size-16 shadow-none dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="bx bx-dots-horizontal-rounded"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                  <li>
                    <a class="dropdown-item" href="#">Action</a>
                  </li>
                  <li>
                    <a class="dropdown-item" href="#">Another action</a>
                  </li>
                  <li>
                    <a class="dropdown-item" href="#">Something else here</a>
                  </li>
                </ul>
              </div> -->
            </div>
          </div>
        </div>
        <div class="row card">
          <div class="col-lg-12">
            <div class="card-datatable table-responsive">
              <div class="table-responsive">
                <table  id="financial_list_table"  class="table  project-list-table table-nowrap align-middle table-borderless">
                  <thead>
                    <tr>
                      <!-- <th scope="col" class="ps-4" style="width: 50px;">
                        <div class="form-check font-size-16">
                          <input type="checkbox" class="form-check-input" id="contacusercheck">
                          <label class="form-check-label" for="contacusercheck"></label>
                        </div>
                      </th> -->
                      <th scope="col" id="financial_id">ID</th>
                      <th scope="col" id="financial_location">Location
                          <input type="text" placeholder="Search" class="form-control form-control-sm" />
                      </th>
                      <th scope="col" id="financial_department">Department
                         <input type="text" placeholder="Search" class="form-control form-control-sm" />
                      </th>
                      <th scope="col" id="financial_category">Category
                         <input type="text" placeholder="Search" class="form-control form-control-sm" />
                      </th>
                      <th scope="col" id="financial_contract_type" style="width: 15%;">Contract Type
                         <input type="text" placeholder="Search" class="form-control form-control-sm" />
                      </th>
                      <th scope="col" id="financial_lower_limit" style="width: 15%;">Lower Limit
                         <input type="text" placeholder="Search" class="form-control form-control-sm" />
                      </th>
                      <th scope="col" id="financial_upper_limit" style="width: 15%;">Upper Limit
                         <input type="text" placeholder="Search" class="form-control form-control-sm" />
                      </th>
                      <th scope="col" id="financial_approver">Approver
                         <input type="text" placeholder="Search" class="form-control form-control-sm" />
                      </th>
                      <th scope="col" id="financial_action" style="">Action</th> 
                    </tr>
                  </thead>
                  
                </table>
              </div>
            </div>
          </div>
        </div>
        
      
      </div>
      <!-- Modal -->
        <div class="modal fade zoomIn" id="deleteRecordModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="btn-close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mt-2 text-center">
                            <i class="bi bi-trash3 display-5 text-danger"></i>
                            <div class="mt-4 pt-2 fs-base mx-4 mx-sm-5">
                                <h4>Are you Sure ?</h4>
                                <p class="text-muted mb-0">Are you Sure You want to Remove this Record ?</p>
                            </div>
                        </div>
                        <div class="d-flex gap-2 justify-content-center mt-4 mb-2">
                            <button type="button" class="btn w-sm btn-light" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn w-sm btn-danger" data-id="" id="delete-paries">Yes, Delete It!</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end modal -->

  <script src="{{ asset('assets/js/jquery-1.10.2.js') }}"></script>
  <script src="{{url('/')}}/Modules/ApprovalRules/resources/assets/js/script.js"></script>
  <script src="https://cdn.datatables.net/v/dt/dt-2.0.8/datatables.min.js"></script>
  <script>
    $('#financial_list_table thead input').on('keyup change', function() {
        var index = $(this).closest('th').index();
        // console.log("index",index);
        // console.log("value",this.value);
        $('#financial_list_table').DataTable().column(index).search(this.value).draw();
        $('#financial_id').removeClass('sorting');
        $('#financial_id').removeClass('sorting_asc');
        $('#financial_id').removeClass('sorting_desc');
        $('#financial_location').removeClass('sorting');
        $('#financial_department').removeClass('sorting');
        $('#financial_category').removeClass('sorting');
        $('#financial_contract_type').removeClass('sorting');
        $('#financial_lower_limit').removeClass('sorting');
        $('#financial_upper_limit').removeClass('sorting');
        $('#financial_approver').removeClass('sorting');
        $('#financial_action').removeClass('sorting');
    });
    $('#financial_list_table thead input').on('click', function(ev) {
         ev.preventDefault(); //appears to have no effect
        return false;
    });
    new DataTable('#financial_list_table', {
        ajax: 'financial/data',
        processing: true,
        serverSide: false,
       // scrollX: true,
         columns: [
                { data: 'id'},
                { data: 'BranchName'},
                { data: 'department',render: DataTable.render.number(null, '') },
                { data: 'contract_categories_name' },
                { data: 'contract_type' },
                { data: 'lower_limit' },
                { data: 'upper_limit' },
                { data: 'approval_required_users',
                 render : function ( data, type, row ) 
                 {
                  var  json_data = JSON.parse(data);
                  //console.log(json_data);
                    if(json_data.length == 0)
                    {
                      return 'Auto Approver';
                    }else
                    {
                      var vals=[];
                        for(var i=0;i<json_data.length;i++){
                           vals.push(json_data[i].name);
                        }
                      return vals;
                    }
                 }
                 },
                {
                    data: null,
                   //className: 'dt-center editor-edit',
                    //defaultContent: '',
                    orderable: false,
                    render : function ( data, type, row ) 
                   {
                    var button = '<li class="list-inline-item"><a href="/contractsdemo/contract-setup/financial-edit/' + data.id+'" data-url="" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit" class="text-primary"><i class="text-primary ti ti-edit font-size-18"></i></a></li>';

                    var button2 ='<li class="list-inline-item"><a class="text-danger parties_delete" onclick=parties_delete(' + data.id+',"/contractsdemo/contract-setup/financial-delete") id="pid_' + data.id+'"  data-id="' + data.id+'" data-url="/contractsdemo/contract-setup/financial-delete" style="color: #cb1717;cursor: pointer;"><i class="text-primary ti ti-trash font-size-18"></i></a></li>';

                     return button+' '+button2;
                   }
                }

            ],
         'columnDefs': [
           {
              'targets': 0,
              'createdCell':  function (td, cellData, rowData, row, col) {
                 $(td).attr('scope', 'row'); 
                 $(td).attr('data-label', 'ID'); 
              }
           },
           {
              'targets': 1,
              'createdCell':  function (td, cellData, rowData, row, col) {
                 $(td).attr('data-label', 'Location'); 
              }
           },
           {
              'targets': 2,
              'createdCell':  function (td, cellData, rowData, row, col) {
                 $(td).attr('data-label', 'Department'); 
              }
           },
           {
              'targets': 3,
              'createdCell':  function (td, cellData, rowData, row, col) {
                 $(td).attr('data-label', 'Category'); 
              }
           },
           {
              'targets': 4,
              'createdCell':  function (td, cellData, rowData, row, col) {
                 $(td).attr('data-label', 'Contract Type'); 
              }
           },
           {
              'targets': 5,
              'createdCell':  function (td, cellData, rowData, row, col) {
                 $(td).attr('data-label', 'Lower Limit'); 
              }
           },
           {
              'targets': 6,
              'createdCell':  function (td, cellData, rowData, row, col) {
                 $(td).attr('data-label', 'Upper Limit'); 
              }
           },
           {
              'targets': 7,
              'createdCell':  function (td, cellData, rowData, row, col) {
                 $(td).attr('data-label', 'Approver'); 
              }
           }
        ]
    });
  </script>
   @endsection  
   