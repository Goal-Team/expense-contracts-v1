@extends('layouts/layoutMaster')

@section('title', 'DataTables - Advanced Tables')

<!-- Vendor Styles -->
@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
  'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
  'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
  'resources/assets/vendor/libs/moment/moment.js',
  'resources/assets/vendor/libs/flatpickr/flatpickr.js',
  'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

<!-- Page Scripts -->
@section('page-script')
@vite([
'resources/assets/js/tables-datatables-advanced.js'
])
@endsection
  @section('content')
    <link href="{{ asset('assets/css/select2.css') }}" rel="stylesheet"/>

    <style>
      label.required:after { content:"*"; color:red;font-size: 15px; font-weight: 900; }
      body{background-color: #e9e9e9;}
      .select_users
      {
          width: 80% !important;
          max-width: 80% !important;
      }
      .select_users_btn
      {
          width: 20% !important;
          max-width: 20% !important;
      }
      .row
      {
        --bs-gutter-x: 0rem;
        --bs-gutter-y: 0rem;
      }
      .financial_form
      {
        padding: 10px;
      }
    </style>   
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-12">
          <div class="mb-3">
            <!-- <h5 class="card-title">Entity Details</h5> -->
              @if ($message = Session::get('success'))
                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                      <b>{{ $message }}</b>
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
              @endif

              @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                          @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                          @endforeach
                      </ul>
                  </div>
              @endif
          </div>
        </div>          
      </div>
      <form class="row" id="financial_form" action="/contractsdemo/contract-setup/financial-edit/{{$financial->id}}" method="POST" enctype="multipart/form-data">
        @csrf
          <div class="row" style="margin-top: 50px;">
              <div class="card" style="box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);">
                  <div class="card-header">
                      <h6 class="card-title mb-0">IF</h6>
                  </div><!-- end card header -->
                  <div class="card-body">
                    <div class="row">
                      <input type="hidden" name="financial_id" value="{{$financial->id}}" />
                      <input type="hidden" id="approval_status" value="{{$financial->approval_status}}" />
                       <div class="col-md-6 financial_form">
                          <label for="location" class="form-label required">Location</label>
                           <select class="form-select" aria-label="select example" id="location" name="location" required>
                              <option value="0">Any / All</option>
                              @foreach($branch as $branch_data)
                                  <option value="{{$branch_data->id}}" {{$financial->location == $branch_data->id  ? 'selected' : ''}}>{{$branch_data->BranchName}}</option>
                              @endforeach
                            </select>
                        </div>
                        <div class="col-md-6 financial_form">
                          <label for="department" class="form-label required">Department</label>
                           <select class="form-select" aria-label="select example" id="department" name="department" required>
                               <option value="0">Any / All</option>
                              @foreach($entity_business as $entity_business_data)
                                  <option value="{{$entity_business_data->id}}" {{$financial->department == $entity_business_data->id  ? 'selected' : ''}}>{{$entity_business_data->name}}</option>
                              @endforeach
                            </select>
                        </div>
                        <div class="col-md-6 financial_form">
                          <label for="category" class="form-label required">Category</label>
                           <select class="form-select" aria-label="select example" id="category" name="category" required>
                              <option value="0">Any / All</option>
                              @foreach($contract_categories as $contract_categories_data)
                                  <option value="{{$contract_categories_data->id}}" {{$financial->category == $contract_categories_data->id  ? 'selected' : ''}}>{{$contract_categories_data->name}}</option>
                              @endforeach
                            </select>
                        </div>
                        <div class="col-md-6 financial_form">
                          <label for="contract_type" class="form-label required">Contract Type</label>
                           <select class="form-select" aria-label="select example" id="contract_type" name="contract_type" required>
                               <option value="0">Any / All</option>
                              @foreach($contract_type as $contract_type_data)
                                  <option value="{{$contract_type_data->contract_type_id}}" {{$financial->contract_type == $contract_type_data->contract_type_id  ? 'selected' : ''}}>{{$contract_type_data->contract_type}}</option>
                              @endforeach
                            </select>
                        </div>
                        <div class="col-md-6 financial_form">
                          <label for="lower_limit" class="form-label">Lower Limit</label>
                          <input type="text" class="form-control numberonly" id="lower_limit" name="lower_limit" value="{{$financial->lower_limit}}" />
                          <div class="invalid-feedback" id="lower_limit_error"></div>
                        </div>
                        <div class="col-md-6 financial_form">
                          <label for="upper_limit" class="form-label">Upper Limit</label>
                          <input type="text" class="form-control numberonly" id="upper_limit" name="upper_limit"  value="{{$financial->upper_limit}}" />
                           <div class="invalid-feedback" id="upper_limit_error">upper limit should be greater than lower limit</div>
                        </div>
                    </div>
                  </div><!-- end card-body -->
              </div><!-- end card -->
          </div>

          <div class="row" style="margin-top: 20px;">
              <div class="card" style="box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);">
                  <div class="card-header">
                      <h6 class="card-title mb-0">THEN</h6>
                  </div><!-- end card header -->

                  <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                          <label for="location" class="form-label">Approver</label>
                            <div>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="approver" id="name" value="name" {{ ($financial->approver=="name")? "checked" : "" }}  />
                                <label class="form-check-label" for="name">Name</label>
                              </div>
                              <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="approver" id="designation" value="designation"  {{ ($financial->approver=="designation")? "checked" : "" }} />
                                <label class="form-check-label" for="designation">Designation</label>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                          <label for="department" class="form-label">Approval Type</label>
                             <div>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="radio" name="approval_type" id="sequential" value="sequential" {{ ($financial->approval_type=="sequential")? "checked" : "" }} />
                                  <label class="form-check-label" for="sequential">Sequential</label>
                                </div>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="radio" name="approval_type" id="parallel" value="parallel" {{ ($financial->approval_type=="parallel")? "checked" : "" }} />
                                  <label class="form-check-label" for="parallel">Parallel</label>
                                </div>
                              </div>
                        </div>  
                        <div class="col-md-12">
                          <label for="department" class="form-label">Approval Status</label>
                            <div>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input approval_status" type="radio" name="approval_status" id="required" value="required"  {{ ($financial->approval_status=="required")? "checked" : "" }} />
                                  <label class="form-check-label" for="required">Approval Required</label>
                                </div>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input approval_status" type="radio" name="approval_status" id="auto" value="auto" {{ ($financial->approval_status=="auto")? "checked" : "" }} />
                                  <label class="form-check-label" for="auto">Auto Approval</label>
                                </div>
                              </div>
                        </div>    
                        <div class="row add_users" style="margin-top: 30px;">
                          @if($financial->approval_status == "required")
                           <?php $approval_required_users = json_decode($financial->approval_required_users); ?>
                             <input type="hidden" id="user_position" value="{{count($approval_required_users)}}" />
                           @foreach($approval_required_users as $key=>$approval_required_users_data)
                            <div class="col-md-6 user_row_{{$key+1}} repeater">
                               <div class="row" style="margin-top: 30px;" id="">
                                 <div class="col-md-6 select_users">
                                    <select class="form-select users approval_user" data-id="{{$key+1}}" aria-label="select example" id="approval_required_users_{{$key+1}}" name="approval_required_users[]" required>
                                      <option value="">Select Approver</option>
                                       @foreach($add_users as $add_users_data)
                                            <option  value="{{$add_users_data->id}}:{{$add_users_data->FirstName}}"  {{$approval_required_users_data->id == $add_users_data->id  ? 'selected' : ''}}>{{$add_users_data->FirstName}}</option>
                                        @endforeach
                                    </select>
                                  </div>
                                  <div class="col-md-6 user_row_operation select_users_btn" style="text-align: center;">
                                    <a id="" class="btn-danger btn-delete" style="font-size: 12px;color: #fff !important;cursor: pointer;">
                                      <i class="ti ti-minus me-1"></i> </a>
                                  </div>
                               </div>  
                            </div>  
                            <div class="col-md-6 user_row_{{$key+1}}">
                             </div>  
                           @endforeach 
                          @endif  
                        </div>                    
                    </div>
                  </div><!-- end card-body -->
              </div><!-- end card -->
          </div>
          <div class="col-md-12" style="text-align: right;">
          <button type="submit" id="financial_save" class="btn btn-success">Submit</button>
          <button type="button" class="btn btn-primary"><a href="/contractsdemo/contract-setup/financial" style="color: #FFF;text-decoration: none;">Cancel</a></button>
        </div>
      </form>
    </div>
    <script type="module" src="{{url('/')}}/Modules/ApprovalRules/resources/assets/js/jquery-1.10.2.js"></script>
    <script type="module" src="{{url('/')}}/Modules/ApprovalRules/resources/assets/js/script.js"></script>
    <script type="module">
      $(document).ready(function() {
           $('.users,#location,#category,#contract_type,#department').select2();
           $('.user_row_operation a:first').remove();
           $('.user_row_operation').first().prepend('<a class="btn-success user_add_row"  data-mode="no_approve" style="font-size: 12px;color: #fff !important;cursor: pointer;"><i class="ti ti-plus me-1"></i></a>');
      // }); 
      // jQuery($ => {
        // $(document).on('change', '.sare-fields', e => {
        //   let $select = $(e.target);
        //   let id = $select.data("id");
        //   let value = $select.val();

        //   let $container = $select.closest('.repeater');
        //   $container.find('.row .data-fields[data-parent=' + id + ']').hide();
        //   $container.find('.data-fields[data-parent=' + id + '][data-sub=' + value + ']').show();
        // });

        // repeater functionality...
        // $('.btn-add').on('click', e => {
        //   let $clone = $('.repeater').first().clone().hide();
        //   $clone.find(':text').val('');
        //   $clone.find('select option:first').prop('selected', true);
        //   $clone.insertAfter('.repeater:last').slideDown();
        // });

        $(document).on('click', '.repeater .btn-delete', e => {
          if (confirm("Are you sure you want to delete this element?")) {
            $(e.target).closest('.repeater').slideUp(400, function() { $(this).remove() });
          }
        });
        $('.user_add_row').click(function (event) {  
          //alert("user_add_row22")
          var index = parseInt($('#user_position').val())+1;
          var mode =  $(this).data('mode');
          //alert(mode);
          $.ajax({
                  headers: {
                              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                          },
                  url: "https://test.legalityevaluate.in/contractsdemo/contract-setup/financial-add-users/"+index,
                  type : "GET",
                  dataType: "html",
                  success:function(data) {
                      //console.log('data',data);
                      if(data)
                      {
                          var position = parseInt($('#user_position').val())+1;
                          $('.add_users').last().append(data);
                          $('.users').select2();
                          $('#user_position').val(position);
                          if(mode == "no_auto")
                          {
                              $("#approval_required_users_1").prop("required", true);                
                              $('.user_row_operation a:first').remove();
                              $('.user_row_operation').first().prepend('<a class="btn-success user_add_row" data-mode="no_auto" style="font-size: 12px;color: #fff !important;cursor: pointer;"><i class="ti ti-plus me-1"></i></a>');
                              var $users = $("#approval_required_users_1");
                              get_users($users,1)
                          }
                          return true;
                      }else
                      {
                           return false;
                      }
                  },
                  error:function(err){
                      var responseJSON = err.responseJSON;
                      console.log('responseJSON',responseJSON);
                      // var message = responseJSON.message;
                      // console.log('error_message',message);
                      return false;
                  }
          }); 
        });
    });
    </script>
@endsection   
   